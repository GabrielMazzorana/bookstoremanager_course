package com.gabrielmazzorana.bookstaremanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstaremanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
